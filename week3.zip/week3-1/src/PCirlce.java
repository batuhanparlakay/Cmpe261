import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

public class PCirlce extends DrawShapesAbstarct{
	private int r;
	private Random ran;
	private Point point;
	private Color color;
		public PCirlce(Point p) {
		super(p);
		point=p;
		ran= new Random();
		r= ran.nextInt(150)+5;
		color= new Color(ran.nextInt(255),
				ran.nextInt(255),
				ran.nextInt(255)
				);
	}
	

	@Override
	public void draw(Graphics e) {
			e.fillOval(point.getX(),
					point.getY(),
					r,r);
		
	}

	@Override
	public double area() {
		// TODO Auto-generated method stub
		return Math.PI*r*r;
	}
	
	public Color getColor() {
		return color;
	}

}
