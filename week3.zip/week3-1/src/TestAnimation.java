import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.Timer;

public class TestAnimation extends JFrame implements ActionListener{
	private int x,  y;
	private Timer timer;
	private Random ran;
	public TestAnimation() {
		
		
		ran= new Random();
		x=10;
		y=10;
		
		timer = new Timer(400, this);
		timer.start();
		
		setSize(600, 650);
		
		setTitle("Animation");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		//setResizable(false);
		setVisible(true);
	}
	
	public static void main(String[] args) {
	
	
		new TestAnimation();
	}
	
	
	
	@Override
	public void paint(Graphics g) {
		// TODO Auto-generated method stub
		super.paint(g);
		
		//g.setColor(Color.RED);
		
	//	g.drawString("Hello CMPE 261 animation", x,y);
		//g.setColor(Color.magenta);
		/*
		g.drawLine(10,50, 300, 400);
		g.drawLine(10,50, 200, 50);
		g.drawLine(300,400, 200, 50);
		*/
		
		//g.fillRect(30, 100, 200, 100);
		//g.drawRect(100, 100, 50, 200);
		g.setColor(Color.GRAY);
		g.fillOval(x+10, y+30, 50, 50);
		g.setColor(Color.BLUE);
		g.fillOval(x, y, x+30, x+40);
		
		
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		x=x+ran.nextInt(10);
		y=y+ran.nextInt(20);
		repaint();
		
	}

}








