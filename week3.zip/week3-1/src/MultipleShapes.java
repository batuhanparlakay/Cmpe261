import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.Timer;

public class MultipleShapes  extends JFrame implements ActionListener{
	private Circle circle;
	private Circle []circles;
	private Timer timer;
	private JButton btnStart, btnStop;
	public MultipleShapes() {
		
		setLayout(null);
		btnStart= new JButton("Start");
		btnStart.setLocation(10,10);
		btnStart.setSize(100,50);
		add(btnStart);
		btnStart.addActionListener(this);
		
		
		
		btnStop= new JButton("Stop");
		btnStop.setLocation(120,10);
		btnStop.setSize(100,50);
		add(btnStop);
		btnStop.addActionListener(this);
		
		
		circle= new Circle();
		
		// initialize circle array
		circles=  new Circle[10];
		
		for(int i=0;i<10;i++) {
			circles[i]= new Circle();
		}
		
		timer= new Timer(100, this);
		//timer.start();
		
		setSize(500,500);
		setVisible(true);
		setTitle("Mulitple Shapes");
	}

	public static void main(String[] args) {
		new MultipleShapes();
	}
	
	@Override
	public void paint(Graphics g) {
		// TODO Auto-generated method stub
		super.paint(g);
		g.setColor(circle.getC());
		g.fillOval(circle.getX(), circle.getY(),
				circle.getR(), circle.getR());
		
		
		for(int i=0;i<circles.length;i++) {
			g.setColor(circles[i].getC());
			g.fillOval(circles[i].getX(), circles[i].getY(),
					circles[i].getR(), circles[i].getR());
		}
		
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource().equals(btnStart)) {
			timer.start();
		}
		else if(e.getSource().equals(btnStop)) {
			timer.stop();
		}
		
		else if(e.getSource().equals(timer)) {
		
		for(int i=0;i<circles.length;i++) {
			circles[i].moveDown();
			circles[i].moveLeft();
		}
		
		repaint();
		} // end of the timer even
		
		
	}
}









