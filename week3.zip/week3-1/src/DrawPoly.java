import java.awt.Graphics;
import java.util.Random;

import javax.swing.JFrame;

public class DrawPoly extends JFrame {
	private IShape []shapes;
	private Random ran;
	
	public DrawPoly() {
		ran= new  Random();
		int type=0;

		shapes= new IShape[10];
		Point p;
		for(int i=0;i<10;i++) {
			p= new Point();
			type= ran.nextInt(20);// between 0 and 10
			if(type>10)
				shapes[i]= new PCirlce(p);
			else
				shapes[i]= new PRectangle(p);
			
		}
		
		
		
		setSize(500,500);
		setVisible(true);
		setTitle("Poly Shapes");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	public static void main(String[] args) {
		new DrawPoly();
	}
	
	@Override
	public void paint(Graphics g) {
		// TODO Auto-generated method stub
		super.paint(g);
		
		for(int i=0;i<shapes.length;i++) {
			g.setColor(shapes[i].getColor());
			shapes[i].draw(g);
			
		}
		
		
		
	}
}
