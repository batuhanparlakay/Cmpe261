import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

public class PRectangle extends DrawShapesAbstarct{
	private int width, hieght;
	private Random ran;
	private Point point;
	private Color color;
	public PRectangle( Point p) {
		super(p);
		point=p;
		
		ran= new  Random();
		width=ran.nextInt(300);
		hieght=ran.nextInt(100);
		
		color= new Color(ran.nextInt(255),
				ran.nextInt(255),
				ran.nextInt(255)
				);
		
		
	}
	@Override
	public void draw(Graphics e) {
		
		e.fillRect(point.getX(),
				point.getY(), width,hieght);
	}
	@Override
	public double area() {
		// TODO Auto-generated method stub
		return width*hieght;
	}
	
	public Color getColor() {
		return color;
	}

}
