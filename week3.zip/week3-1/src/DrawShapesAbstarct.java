import java.awt.Color;
import java.awt.Graphics;

public abstract class DrawShapesAbstarct implements IShape{
	private Point center;
	public DrawShapesAbstarct(Point p) {
		center= p;
	}

	@Override
	public double distance( ) {
		double result=  Math.pow(center.getX()-0,2)
				+Math.pow(center.getY()-0,2);
		
		return Math.sqrt(result);
	}

	@Override
	public abstract void draw(Graphics e);

	@Override
	public abstract double area();
	
	public abstract Color getColor();

}
