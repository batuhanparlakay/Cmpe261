import java.util.Random;

public class Point {
	private int x,y;
	private Random ran;
	public Point() {
		ran= new Random();
		x=ran.nextInt(200);
		y=ran.nextInt(200);
		
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public Random getRan() {
		return ran;
	}
	public void setRan(Random ran) {
		this.ran = ran;
	}
	

}
