import java.awt.Color;
import java.awt.Graphics;

public interface IShape {
	public double distance();
	public void draw( Graphics e);
	public double area();
	public Color getColor();

}
