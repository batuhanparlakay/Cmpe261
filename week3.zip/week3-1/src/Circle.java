import java.awt.Color;
import java.util.Random;

public class Circle {
	private int x , y,r;
	private Color c;
	private Random ran;
	
	public Circle() {
		
		ran= new Random();
		x= ran.nextInt(100)+10;// numbers between 10 and 110
		y= ran.nextInt(250)+10;// numbers between 10 and 110
		r= ran.nextInt(200)+10;// numbers between 10 and 110
		c= new Color(ran.nextInt(255), 
				ran.nextInt(255), ran.nextInt(255));
		
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public int getR() {
		return r;
	}

	public Color getC() {
		return c;
	}
	
	public void moveLeft() {
		x=x-5;
		
	}
	
	public void moveDown() {
		y=y+ran.nextInt(10);
		
	}
	
	

}







