#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Dec 16 14:30:17 2019

@author: murat
"""

class A:
    def __init__(self,a,b):
        self.a=a
        self.b=b
    def add(self):
        return self.a+self.b

class B:
    def __init__(self,a,b,c):
        self.a=a
        self.b=b
        self.c=c
        
    def mul(self):
        return self.a*self.b*self.c



class C:
    def __init__(self,a,b):
        self.a=a
        self.b=b

    def sub(self,a,b):
        
        return self.a - self.b 
        

class D(A,B,C):
    def __init__(self,a,b,c):
        #super().__init__(a,b)
        A.__init__(self,a,b)
        B.__init__(self,a,b,c)
        C.__init__(self,a,b)
        self.a=a
        self.b=b
        
    def total(self):
        return self.a+self.b+20




d = D(2,3,5)
print(d.total())
print(d.mul())
        
        
        
        
        