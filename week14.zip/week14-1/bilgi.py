#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Dec 16 14:02:15 2019

@author: murat
"""
print("Hello")

class Address:
    def __init__(self,city, postCode):
        self.city = city
        self.post = postCode

    def getAddress(self):
        return "city is {}, post code {}".format(self.city,
                        self.post)


class Person:
    def __init__(self, name, age,add):
        self.__name = name
        self.age = age
        self.add= add
    
    def getPerson(self):
        return "Name is"+self.__name+" age is:"+str(self.age)+self.add.getAddress()        
    
    def whoisThis(self):
        print("Person:" +self.getPerson())
    
    def getName(self):
            return self.__name

    
        
x = Address("IST", 45)
p = Person("Ali",3,x)
print(p.getPerson())
p.whoisThis()
print(p.age)
print(p.getName())

        
a = Address("IST", 34)
print(a.getAddress())

class Student(Person):
    def __init__(self,n,a,add,dept,grade):
        super().__init__(n,a,add)
        self.dept = dept
        self.grade = grade
    
    def getStudent(self):
        return self.getPerson()+"dept is"+self.dept+" grade"+self.grade
    
    def whoisThis(self):
        print("student"+self.getStudent())
    

student = Student("Ali",34,a,"CEMPE", "AA")
print(student.getStudent())

student.whoisThis()
p.whoisThis()

def testPoly(data):
    data.whoisThis()


print("Test Poly....")
testPoly(p)
testPoly(student)









