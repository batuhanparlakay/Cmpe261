
public class TestGroup {
	public static void main(String[] args) {
		
		ThreadGroup g1= new ThreadGroup("Bilgi");
		ThreadGroup g2= new ThreadGroup("Istanbul");
		
		Thread t1= new Thread(g1,new TestThreadGroup1(),"b1");
		Thread t2= new Thread(g1,new TestThreadGroup1(),"b2");
		
		ThreadGroup p1= new ThreadGroup(g2,"İstabnul");
		ThreadGroup p2= new ThreadGroup(g2,"İstabnul");
		
		g1.list();
		//g2.list();
		
		
	}

}
