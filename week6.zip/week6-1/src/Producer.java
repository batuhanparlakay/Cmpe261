
public class Producer extends Thread{
	private Share s;
	public Producer(Share s) {
		// TODO Auto-generated constructor stub
		this.s=s;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(true) {
			s.inc();
			try {
				sleep(1);
			}
			catch (InterruptedException e) {
				// TODO: handle exception
				return;
			}
		}
	}

}
