
public class Consumer extends Thread{
	private Share s;
	public Consumer(Share s) {
		// TODO Auto-generated constructor stub
		this.s=s;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(true) {
			s.dec();
			try {
				sleep(1);
			}
			catch (InterruptedException e) {
				// TODO: handle exception
				return;
			}
		}
	}

}
