import java.util.Random;

public class Share {
	private int c;
	private Random ran;
	
	public Share() {
		c=0;
		ran = new Random();
	}
	
	public synchronized void inc() {
		int p= ran.nextInt(10);
		if(c+p>200) {
			try {
				
				System.out.println("Producer: current value "+c);
				System.out.println("Producer generated data is "+p);
				wait();
				Thread.currentThread().sleep(700);
				
			}
			catch (InterruptedException e) {
				// TODO: handle exception
			}
			
			
		}
		else {
			c=c+p;
			System.out.println("Producer: data is updated: "+c);
			notifyAll();
			
		}
		
	}
	
	

	public synchronized void dec() {
		int p= ran.nextInt(10);
		if(c-p< 0) {
			try {
				
				System.out.println("Consumer: current value "+c);
				System.out.println("Consuer generated data is "+p);
				wait();
				Thread.currentThread().sleep(700);
				
			}
			catch (InterruptedException e) {
				// TODO: handle exception
			}
			
			
		}
		else {
			c=c-p;
			System.out.println("Consumer: data is updated: "+c);
			notifyAll();
			
		}
		
	}
	
	

}
