
public class ThreaGroup2 extends Thread{
	public ThreaGroup2(ThreadGroup g, String name) {
		super(g,name);
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Group-Quiz");
	}

}
