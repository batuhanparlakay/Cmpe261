
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Share s= new Share();
		Producer p1= new Producer(s);
		p1.start();
		Producer p2= new Producer(s);
		//p2.start();
		
		Consumer c1= new Consumer(s);
		c1.start();
		/*
		Consumer c2= new Consumer(s);
		c2.start();
		
		Consumer c3= new Consumer(s);
		c3.start();
		
		Consumer c4= new Consumer(s);
		c4.start();
		*/
		
		try {
			Thread.currentThread().sleep(10000);
			p1.interrupt();
			c1.interrupt();
			
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		
		
		System.out.println("End of the main METHOD");
		

	}

}
