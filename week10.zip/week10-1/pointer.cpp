// example about pointes...
#include <iostream>
using namespace std;
#include <vector>

# define size2 5

const int data=5;

int sum(int*,int*);
int *myArray(int[]);
int total(int,int);
	

int main(){
	int mydata[size2]={10,20,30,40,50};
	/*

	int *p;
	int k=30;
	p=&k;
	cout << *p<<endl;
	*p=400;
	cout << *p<<endl;
       cout << k<<endl;
	int *pp=mydata;
	cout<<*(pp+2)<<endl;
	for(int i=0;i<size;i++){
		cout<<*(pp+i)<<endl;
	}

      */
	int x=20;
	int y=40;
	cout<<sum(&x,&y)<<endl;
       cout<<total(x,y)<<endl;

	int *ist=myArray(mydata);
     for(int i=0;i<size2;i++){
		cout<<*(ist+i)<<endl;
	}

     vector <int > key(size2);
     key.push_back(20);
	cout<<"\n";
     cout<<key.size()<<endl;
	

	
}
int sum(int*a,int*b){
	return *a + *b;
}
int total(int a,int b){
	return  a +  b;
}


int *myArray(int p[]){
	static int temp [data];
	for(int i=0;i<data;i++)
		temp[i]=p[i]*3;
	

	return temp;
}









