#include <iostream>
#include <string>
using namespace std;

class Person {
	
	public:
		Person(string, int );
		int getAge();
		void setAge(int );
		void show();
	private:
		string name;
		int age;
};

