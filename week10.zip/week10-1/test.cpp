
#include <iostream>
#include <string>
#include "person.h"
using namespace std;

int main(){
Person p("Ali", 23);
cout<<p.getAge()<<endl;

p.show();


return 0;
}
