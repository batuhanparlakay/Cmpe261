#include <iostream>
#include <string>
#include "person.h"
using namespace std;

		Person::Person(string name, int age){
			this->name = name;
			this->age=age;
		}

		int Person::getAge(){
			return age;	
		}

		void Person::setAge(int age){
			this->age=age;
		}

		void Person::show(){
			cout<<"name is: "<<name<<" age is: "<<age<<endl;
		}



