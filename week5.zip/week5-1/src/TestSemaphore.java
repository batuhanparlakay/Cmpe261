import java.util.concurrent.Semaphore;

public class TestSemaphore {
	public static void main(String[] args) {
		
		ATM atm= new ATM(1000);
		Semaphore sem= new Semaphore(1);
		UserSemaphore u1= new UserSemaphore(atm, 800, sem);
		UserSemaphore u2= new UserSemaphore(atm, 700, sem);
		
		Thread t1= new Thread(u1, "Ali");
		Thread t2= new Thread(u2, "Fatma");
		
		t1.start();
		t2.start();
	}

}
