import java.util.concurrent.Semaphore;

public class UserSemaphore implements Runnable{
	private ATM atm;
	private int money;
	private Semaphore sem;

	public UserSemaphore(ATM atm, int money, Semaphore sem) {
		// TODO Auto-generated constructor stub
		this.atm=atm;
		this.money=money;
		this.sem=sem;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		//super.run();
		try {
			sem.acquire();
		
				String name= Thread.currentThread().getName();
				System.out.println(name+"  "+atm.getMoney(money));
			sem.release();
		}
		catch (InterruptedException e ) {
			// TODO: handle exception
		}
	}
}
