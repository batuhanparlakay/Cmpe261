import java.util.concurrent.locks.ReentrantLock;

public class TestSafeUser {
	public static void main(String[] args) {
		ATM atm= new ATM(1000);
		ReentrantLock lock= new ReentrantLock();
		UserSafe u1= new UserSafe(atm, 800, lock);
		UserSafe u2= new UserSafe(atm, 500, lock);
		UserSafe u3= new UserSafe(atm, 200, lock);
		u3.setName("Erdem");
		u1.setName("Ali");
		u1.start();
		u2.setName("Fatma");
		u2.start();
		u3.start();
	}

}
