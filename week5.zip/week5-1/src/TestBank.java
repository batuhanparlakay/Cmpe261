
public class TestBank {
	public static void main(String[] args) {
		ATM a= new ATM(1000);
		User u1= new User(a, 800);
		u1.setName("Ali");
		u1.start();
		
		User u2= new User(a, 800);
		u2.setName("Fatma");
		u2.start();
		
		UserRunnable u3= new UserRunnable(a, 500);
		Thread t3= new Thread(u3,"Erdem");
		//t3.setName("Erdem");
		t3.start();
	}

}


