import java.util.concurrent.locks.ReentrantLock;

public class UserSafe extends Thread {
	
	private ATM atm;
	private int money;
	private ReentrantLock kilt;
	
	public UserSafe(ATM atm, int money, ReentrantLock k) {
		// TODO Auto-generated constructor stub
		this.atm=atm;
		this.money=money;
		kilt=k;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		//super.run();
		kilt.lock();
		String name= Thread.currentThread().getName();
		System.out.println(name+" "+atm.getMoney(money));
		kilt.unlock();
	}


}
