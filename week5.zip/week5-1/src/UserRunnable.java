
public class UserRunnable implements Runnable{

	private ATM atm;
	private int money;
	
	public UserRunnable(ATM atm, int money) {
		// TODO Auto-generated constructor stub
		this.atm=atm;
		this.money=money;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		//super.run();
		String name= Thread.currentThread().getName();
		System.out.println(name+"  "+atm.getMoney(money));
	}
}