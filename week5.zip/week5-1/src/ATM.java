
public class ATM {
	private int balance;
	public ATM(int balance) {
		// TODO Auto-generated constructor stub
		this.balance=balance;
	}
	
	public String getMoney(int money) {
		if(balance>= money) {
			try {
				Thread.sleep(100);
				balance=balance-money;
			}
			catch (InterruptedException e) {
				// TODO: handle exception
			}
			return "You can get "+ money+" TL!.";
		}
		else {
			return "Your balance is "+ balance+ " TL";
		}
	
	}

}
