import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class TestBorder extends JFrame{
	private JTextField txtOne,txtTwo,txtResult;
	private JButton btnCalculate, btnReset,btnExit;
	private JLabel lblFirst, lblSecond,lblResult;
	private JPanel pnlCalculate;
	public TestBorder() {
		setLayout(new BorderLayout());
		
		lblFirst= new JLabel("First Number");
		add(lblFirst,BorderLayout.NORTH);
		txtOne= new JTextField();
		txtOne.setColumns(10);
		add(txtOne,BorderLayout.SOUTH);
		
		
		lblSecond= new JLabel("Second Number");
		add(lblSecond,BorderLayout.EAST);
		txtTwo= new JTextField();
		txtTwo.setColumns(10);
		add(txtTwo,BorderLayout.WEST);
		
		lblResult= new JLabel("Result");
		//add(lblResult,BorderLayout.CENTER);
		
		txtResult= new JTextField();
		txtResult.setColumns(10);
		txtResult.setEditable(false);
		//add(txtResult);
		
		btnCalculate= new JButton("Calculate");
		btnCalculate.setBackground(Color.yellow);
		//add(btnCalculate);
		
		
		btnReset= new JButton("Reset");
		btnReset.setBackground(Color.yellow);
		//add(btnReset);
		
		btnExit= new JButton("Exit");
		btnExit.setBackground(Color.yellow);
		//add(btnExit);
		
		pnlCalculate= new JPanel();
		pnlCalculate.setLayout(new FlowLayout());
		pnlCalculate.add(btnExit);
		pnlCalculate.add(btnReset);
		pnlCalculate.add(btnCalculate);
		pnlCalculate.add(txtResult);
		pnlCalculate.add(lblResult);
		add(pnlCalculate,BorderLayout.CENTER);
		// register buttons to respond actions...
		//btnCalculate.addActionListener(this);
		//btnReset.addActionListener(this);
		//btnExit.addActionListener(this);
		
		setSize(500, 400);
		setVisible(true);
		setTitle("Calculate");
		//setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		getContentPane().setBackground(Color.pink);
		
	}
	public static void main(String[] args) {
		new TestBorder();
	}
	

}













