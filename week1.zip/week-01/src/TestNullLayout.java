import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class TestNullLayout extends JFrame{
	private JTextField txtOne,txtTwo,txtResult;
	private JButton btnCalculate, btnReset,btnExit;
	private JLabel lblFirst, lblSecond,lblResult;
	
	public TestNullLayout() {
		setLayout(null);
		
		lblFirst=new JLabel();
		lblFirst.setText("First Number");
		lblFirst.setSize(100, 50);
		lblFirst.setLocation(10, 50);
		
		add(lblFirst);
		
		txtOne= new JTextField();
		txtOne.setLocation(120, 50);
		txtOne.setSize(50, 50);
		txtOne.setToolTipText("Enger an integer number");
		add(txtOne);
		
		
		lblSecond=new JLabel();
		lblSecond.setText("Second Number");
		lblSecond.setSize(110, 50);
		lblSecond.setLocation(10, 100);
		
		add(lblSecond);
		
		txtTwo= new JTextField();
		txtTwo.setLocation(120, 100);
		txtTwo.setSize(50, 50);
		txtTwo.setToolTipText("Enger an integer number");
		add(txtTwo);
		
		
		btnCalculate= new JButton("Calculate");
		btnCalculate.setLocation(10, 150);
		btnCalculate.setSize(100, 50);
		//txtTwo.setToolTipText("Enger an integer number");
		add(btnCalculate);
		

		btnReset= new JButton("Reset");
		btnReset.setLocation(170, 150);
		btnReset.setSize(100, 50);
		//txtTwo.setToolTipText("Enger an integer number");
		add(btnReset);

		btnExit= new JButton("Exit");
		btnExit.setLocation(360, 150);
		btnExit.setSize(100, 50);
		//txtTwo.setToolTipText("Enger an integer number");
		add(btnExit);

		
		
		
		
		setSize(500, 400);
		setVisible(true);
		setTitle("Calculate");
		//setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		getContentPane().setBackground(Color.pink);
		
	}
	
	public static void main(String[] args) {
		new TestNullLayout();
	}
	
	

}
