import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class TestGrid extends JFrame{

	private JTextField txtOne,txtTwo,txtResult;
	private JButton btnCalculate, btnReset,btnExit;
	private JLabel lblFirst, lblSecond,lblResult;
	
	
	public TestGrid() {
		// test the FlowLayot
		setLayout(new GridLayout(4,2));
		lblFirst= new JLabel("First Number");
		add(lblFirst);
		txtOne= new JTextField();
		txtOne.setColumns(10);
		add(txtOne);
		
		
		lblSecond= new JLabel("Second Number");
		add(lblSecond);
		txtTwo= new JTextField();
		txtTwo.setColumns(10);
		add(txtTwo);
		
		lblResult= new JLabel("Result");
		add(lblResult);
		
		txtResult= new JTextField();
		txtResult.setColumns(10);
		txtResult.setEditable(false);
		add(txtResult);
		
		btnCalculate= new JButton("Calculate");
		btnCalculate.setBackground(Color.yellow);
		add(btnCalculate);
		
		
		btnReset= new JButton("Reset");
		btnReset.setBackground(Color.yellow);
		add(btnReset);
		
		btnExit= new JButton("Exit");
		btnExit.setBackground(Color.yellow);
		//add(btnExit);
		
		// register buttons to respond actions...
		//btnCalculate.addActionListener(this);
		//btnReset.addActionListener(this);
		//btnExit.addActionListener(this);
		
		setSize(500, 400);
		setVisible(true);
		setTitle("Calculate");
		//setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		getContentPane().setBackground(Color.pink);
	}
	
	public static void main(String[] args) {
		new TestGrid();
	}

	
}
