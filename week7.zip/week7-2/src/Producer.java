
public class Producer extends Thread{
	private Shared s;
	public Producer(Shared s) {
		this.s=s;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(true) {
			
			try {
			s.inc();
			sleep(1);
			}
			catch (InterruptedException e) {
				return;
			}
			
		}
	}

}
