import java.util.Random;

public class TaskPool implements Runnable{
	private Random ran;
	private int p;
	public TaskPool() {
		ran= new Random();
		p=ran.nextInt(9000)+200;
	}

	@Override
	public void run() {
		
		try {
			Thread.currentThread().sleep(p);
			System.out.print(Thread.currentThread().getId());
			System.out.println(" Generate number is:"+p);
			
			
		}
		catch (InterruptedException  e) {
			// TODO: handle exception
		}
	
		
	}

}
