
public class Consumer implements Runnable{
	private Shared s;
	public Consumer(Shared s) {
		this.s=s;
	}

	@Override
	public void run() {
	
		while(true) {
		s.dec();
		try {
			Thread.currentThread().sleep(1);
		}
		catch (InterruptedException e) {
			return;
		}
		
		}
		
	}
	

}
