import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TestPool {
	private ExecutorService myPool;
	public TestPool(int number) {
		myPool=Executors.newFixedThreadPool(number);
	}
	
	public void executeMyPools() {
		while(true) {
			
			myPool.execute(new TaskPool());
			
		}
	}
	
	public static void main(String[] args) {
		
		TestPool t= new TestPool(5);
		t.executeMyPools();
	}

}
