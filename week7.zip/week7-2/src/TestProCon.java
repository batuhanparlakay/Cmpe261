
public class TestProCon {
	public static void main(String[] args) {
		Shared s= new Shared();
		Producer p1= new Producer(s);
		p1.start();
		/*
		Producer p2= new Producer(s);
		p2.start();
		
		Producer p3= new Producer(s);
		p3.start();
		*/
		
		Thread c1= new Thread(new Consumer(s));
		c1.start();
		/*
		Thread c2= new Thread(new Consumer(s));
		c2.start();
		
		
		Thread c3= new Thread(new Consumer(s));
		c3.start();
    */
		try {
			Thread.currentThread().sleep(5000);
			p1.interrupt();
			c1.interrupt();
			
		}
		catch (Exception e) {
			System.out.println("error in main ");
		}
		
		System.out.println("End of the main");
	}

}
