import java.util.Random;

public class Shared {
	private int c;
	private Random ran;
	 public Shared() {
		c=0;
		ran= new Random();
		 
	}
	 
	 // increase
	 
	 public synchronized void inc() {
		 
		 int p= ran.nextInt(10);
		 if(c+p>100) {
			 try {
				 System.out.println("Producer is wating...");
				 System.out.println("Producer current value "+c);
				 System.out.println("Producer generatged data is: "+p);
				 wait();
				 Thread.currentThread().sleep(ran.nextInt(1000)+200);
			 }
			 catch (InterruptedException e) {
				System.out.println("error in inc...");
			}
		 }
		 else{
			 c=c+p;
			 notifyAll();
			 System.out.println("Producer new common data is: "+c);
		 }
		 
	 }
	 


	 public synchronized void dec() {
		 
		 int p= ran.nextInt(10);
		 if(c-p<0) {
			 try {
				 System.out.println("Consumer is wating...");
				 System.out.println("Consumer current value "+c);
				 System.out.println("Consumer generatged data is: "+p);
				 wait();
				 Thread.currentThread().sleep(ran.nextInt(1000)+200);
			 }
			 catch (InterruptedException e) {
				System.out.println("error in dec...");
			}
		 }
		 else{
			 c=c-p;
			 notifyAll();
			 System.out.println("Consumer new common data is: "+c);
		 }
		 
	 }

}
