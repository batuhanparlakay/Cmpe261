
public class TestGroup {
	public static void main(String[] args) {
		ThreadGroup g1= new ThreadGroup("group one");
		ThreadGroup g2= new ThreadGroup("group two");
		
		Thread t1= new Thread(g1,new TaskOne(),"erdem");
		Thread t2= new Thread(g1,new TaskOne(),"erdem2");
		Thread t3= new Thread(g1,new TaskOne(),"erdem3");
		
		TaskTwo p1= new TaskTwo(g2,"Fatma1");
		TaskTwo p2= new TaskTwo(g2,"Fatma2");
		TaskTwo p3= new TaskTwo(g2,"Fatma3");
		
		g1.setDaemon(true);
		g1.list();
		
	}

}
