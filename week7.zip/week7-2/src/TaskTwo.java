
public class TaskTwo extends Thread{
	public TaskTwo(ThreadGroup g, String n) {
		super(g,n);
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Task Two");
	}

}
