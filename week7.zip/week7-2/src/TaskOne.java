
public class TaskOne implements Runnable{
	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Task one");
		
	}

}
