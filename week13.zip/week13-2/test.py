

print("Hello python...")
print(3)
x="Bilgi"
#print(x*10)
t=23
z=300
print(x,t,z,sep=" ",end="\n ")
print("end data")

data=[1,2,3,4,5,6,-1,3,-45,56]
print(data)
#data.remove(3)
print(data)
print(min(data))
print(max(data))
data.sort()
print(data)
data.reverse()
print(data)

k=(1,2,3,4,5,6,7,5)
print(k)
print(k[3])

for i in k:
	print (i,sep= " "  ,end=" ")
print()

table = [[1,2,3],[2,3],[20,30,40,50]]
print(table)

for i in table:
	for j in i:
		print(j, end=" ")
	print()


for i in range(len(table)):
	for j in range(len(table[i])):
		print(table[i][j],end=" ")
	print()

	
#functions...

def sum(a,b):
	return a+b

def hi():
	print("hi")
print("test functions...")
print(sum(2,3))
print(sum("ali","erdem"))

def total (a, b, c=30):
	return a+b+c

print(total(2,30))
print(total(2,3,4))

hi()





























