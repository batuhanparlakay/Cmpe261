#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Dec 12 16:37:15 2019

@author: murat
"""

import pandas as pd
from pandas import ExcelFile
from pandas import ExcelWriter

name= ["ali", "erhan","bilgi", "ankara"]
data= [10,20,30,40]

df = pd.DataFrame(
        {"name":name, "data":data}
        )

writer = ExcelWriter("mydata.xls")
df.to_excel(writer,"sheet1", index  = False)
writer.save()