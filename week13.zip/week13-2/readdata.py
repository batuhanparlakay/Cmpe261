#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Dec 12 16:32:21 2019

@author: murat
"""

import pandas as pd
df = pd.read_excel("student.xls","Sheet1")
print(df)
names= df["age"]
print(names)

for i in names:
    print(i)
