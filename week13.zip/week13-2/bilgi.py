#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Dec 12 16:26:38 2019

@author: murat
"""

print("hello")
import random

data = []
print(data)
for i in range (20):
        data.append(random.randint(10,30))
        

for i in data:
        print(i)