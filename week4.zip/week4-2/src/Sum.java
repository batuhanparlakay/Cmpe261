
public class Sum implements Runnable{
	private int s,t;
	public int total;
	public Sum(int s, int t) {
		this.s=s;
		this.t=t;
		total=0;
	}
	// helper methot to sum numbers between given parameters
	public void mySum() {
		for(int i=s;i<=t;i++)
			total=total+i;
	}

	@Override
	public void run() {
		mySum();
		
	}
	

}
