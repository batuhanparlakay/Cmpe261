
public class TestThread extends Thread {
	public void hi() {
		System.out.println("hi");
	}
	public void hii() {
		System.out.println("hii");
	}
	
	public void fo() {
		System.out.println("fo");
	}
	
	public void foo() {
		System.out.println("foo");
	}
	public void run() {
		System.out.println("run-bilgi");
		fo();
		foo();
	}
	public static void main(String[] args) {
		
		TestThread t= new TestThread();
		TestThread t2= new TestThread();
		t.setName("MyThread");
		//t.run();
		t.start();
		t.hi();
		t.hii();
		t.fo();
		t.foo();
		System.out.println(t.getName());
		System.out.println(Thread.currentThread().getName());
		System.out.println(t.getId());
		System.out.println(t2.getId());
		
		
		
		
	}

}





