
public class TestSum {
	public static void main(String[] args) {
		
		Sum s1= new Sum(1, 50);
		Thread t1= new Thread(s1);
		
		Sum s2= new Sum(51, 100);
		Thread t2= new Thread(s2);
		
		t1.start();
		t2.start();
		
		try {
			t1.join();
			t2.join();
		}
		catch (InterruptedException e) {
			// TODO: handle exception
		}
		
			
		int total= s1.total+s2.total;
		
		System.out.println("Total result is:"+total );
		
	}

}
