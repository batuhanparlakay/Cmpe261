
public class TestThread2 implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Start the run method");
		loop();
		
	}
	public void loop() {
		while(true) {
			System.out.println("Loop");
			try {
				Thread.currentThread().sleep(500);
			}
			catch (InterruptedException e) {
				// TODO: handle exception
			}
		}
	}
	
	public void hi() {
		System.out.println("hi");
	}
	
	public void hii() {
		System.out.println("hii");
	}

}
