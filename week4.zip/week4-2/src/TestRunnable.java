
public class TestRunnable {
	public static void main(String[] args) {
		TestThread2 t= new TestThread2();
		Thread myThread= new Thread(t);
		//t.run();
		myThread.start();
		t.hi();
		//t.loop();
		t.hii();
		System.out.println("End of the program");
	}

}
