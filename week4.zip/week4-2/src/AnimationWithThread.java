import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class AnimationWithThread extends JPanel implements Runnable{
	private int x, y;
	public AnimationWithThread() {
		x=10;
		y=10;
		Thread t= new Thread(this);
		t.start();
	}
	@Override
	public void paint(Graphics g) {
		// TODO Auto-generated method stub
		super.paint(g);
		g.fillOval(x, y, 100, 100);
	}

	public static void main(String[] args) {
		JFrame window= new JFrame();
		window.add(new AnimationWithThread());
		window.setSize(500, 500);
		window.setVisible(true);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setTitle("Game with Thread");
	}
	
	private void moveRight() {
		x=x+5;
		y=y+5;
	}
	@Override
	public void run() {
		for(;;) {
		moveRight();
		//System.out.println(x);
		try {
			Thread.currentThread().sleep(100);
		}
		catch (InterruptedException e) {
			// TODO: handle exception
		}
		repaint();
		}
		
	}
}















