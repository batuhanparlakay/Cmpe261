#include<iostream>
using namespace std;
#include "big.h"
class A{
	private:
	int x;
	int y;
	public:
	int add(int a,int b){
		return a+b;
	}

        int add(int a,int b,int c){
		return a+b+c;
	}
	A(int a, int b){
		x=a;
		y=b;
	}
	void info(){
		cout<<"x is:"<<x<<"Y is: "<<y<<endl;		
	}
	~A(){
		cout<<"This is destructor of A classs\n";
         }

};


class B{
	public:
	int sub(int a,int b){
		return a-b;
	}
 
        
};

class C:public A,public B{
	private:
	int z;
	public:
	int mul(int a,int b){
		int x=add(a,b);
		int y=sub(a,b);
	return x*y;
	}
	C(int a,int b, int c):A(a,b){
		z=c;
	}
	void info(){
	 A::info();
	 cout<<"Z is: "<<z<<endl;
	}
};

int main(){
     /*
        C c;
	cout<<c.mul(2,3)<<endl;
	cout<<"hello\n";

	A a(10,20);
	a.info();
*/
	C c2(10,20,30);
	c2.info();
	cout<<"Test template: "<<max2(2,3)<<endl;
        cout<<"Test template: "<<max2(2.6,6.7)<<endl;
}






