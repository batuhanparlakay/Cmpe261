template <class T>
 T max2(T a, T b){

	if(a>b)
		return a;
	else 
		return b;
 }


