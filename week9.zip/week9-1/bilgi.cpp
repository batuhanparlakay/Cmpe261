#include <iostream>
using namespace std;
void hello();
int min(int,int); 
void hi(void);

int main(){

	cout<<"Hello CPP \n";
	cout<<"CMPE 261"<<std::endl;
	cout<<"Bye\n";
	cout<<"The small number is: "<<min(3,4)<<"\n";
	hello();
	hi();
	
}
 void hello(){
	cout<<"Hello \n";
}
int min(int a, int b){
	return a+b;
}


void hi(void){
	cout<<"hi"<<endl;
	return;
}

