#include <iostream>
using namespace std;

void swapOne(int, int);
void swapTwo(int&, int&);
int main(){

int m=10;
int n=20;
swapOne(m,n);
cout<<"M is:"<<m<<"N is:"<<n<<endl;

swapTwo(m,n);
cout<<"M is:"<<m<<"N is:"<<n<<endl;

	
}

// functions...
void swapOne(int a, int b){
	int temp=a;
	a=b;
	b=temp;
	
	cout<<"inside fucntion m and n"<<a<<b<<endl;
}

void swapTwo(int& a, int& b){
	int temp=a;
	a=b;
	b=temp;

cout<<"inside fucntion2 m and n"<<a<<"  "<<b<<endl;
}

