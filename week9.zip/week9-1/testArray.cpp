using namespace std;
#include <iostream>
int data[4]={1,2,3,4};
const int size=10;
int mydata[size]={1,2,3,4,5,-100,7,8,9,10};

void printArray(int [],int);
int minArray(int [], int);

int main(){
cout <<"hello \n";
printArray(mydata,size);
printArray(data,4);

cout<<"The small number is: "<<minArray(mydata,size)<<endl;
cout<<"The small number is: "<<minArray(data,4)<<endl;
return 0;
}

int minArray(int p[],int size){
	int min=p[0];
	for(int i=1;i<size;i++){
		if(min>p[i]){
			min=p[i];
		}
	}	
	return min;
}
void printArray(int p[], int size){
	for(int i=0; i<size;i++)
		cout<<p[i]<<endl;
}








