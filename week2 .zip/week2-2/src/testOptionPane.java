import javax.swing.JOptionPane;


public class testOptionPane {
	
	public static void main(String[] args) {
		
		/*
		//default
		JOptionPane.showMessageDialog(null, "Hello CMPE");
		// information
		JOptionPane.showMessageDialog(null,"Hello CMPE 408",
				"Bilgi CMPE",JOptionPane.INFORMATION_MESSAGE
				);
		
		JOptionPane.showMessageDialog(null, "What is your name",
				"Input Name", JOptionPane.QUESTION_MESSAGE);
		
		JOptionPane.showMessageDialog(null, "Number format error",
				"Error Message", JOptionPane.ERROR_MESSAGE	
				);
		JOptionPane.showMessageDialog(null,
				"Exit the program", "Exit",
				JOptionPane.WARNING_MESSAGE
				);
				
		
		String name= JOptionPane.showInputDialog("What is your name");
		//System.out.println("My name is: "+name);
		JOptionPane.showMessageDialog(null, "My name is "+name,
				"Name of the user", JOptionPane.INFORMATION_MESSAGE
				);
		String strAge= JOptionPane.showInputDialog("How old are you?");
		JOptionPane.showMessageDialog(null,
				"I am "+strAge+" year old", "Age of the user",
				JOptionPane.INFORMATION_MESSAGE);
		
		
		String []days= {"Monday","Tuesday","Wednesday","Sunday" };
		String day= (String)JOptionPane.showInputDialog(null,
				"Today is: ","Select a day",
				JOptionPane.QUESTION_MESSAGE,
				null, days,days[2]		
				);
		
		//System.out.println("Today is: "+day);
		
		JOptionPane.showMessageDialog(null, "Today is"+day,
				"Selection", JOptionPane.INFORMATION_MESSAGE);
		
		
		
		int n=JOptionPane.showConfirmDialog(null, "Are you a student",
				"Question",JOptionPane.YES_NO_CANCEL_OPTION);
		
		if(n==JOptionPane.YES_OPTION) {
			System.out.println("This is YES button");
		}
		else if(n==JOptionPane.NO_OPTION) {
			System.out.println("This is NO");
		}
		else {
			System.out.println("This is Cancel");
		}
		
		*/
		
		int p=1;
		while(true) {
		
		Object option[]= {"Evet","Hayır","Iptal","Tamam","Vazgeç"};
		int z= JOptionPane.showOptionDialog(null,
				"Ne yapacaksin", "Seç",
				JOptionPane.YES_NO_CANCEL_OPTION,
				JOptionPane.QUESTION_MESSAGE,
				null, option, option[2]);
		
		
		//System.out.println("Optin is: "+z);
		JOptionPane.showMessageDialog(null, "The Optin is: "+z);
		
		p= JOptionPane.showConfirmDialog(null, 
				"Continue?","Select",
				JOptionPane.YES_NO_OPTION
				);
		if(p==JOptionPane.NO_OPTION)
			break;
		
		}
		
		
		
		
	}

}




















