import javax.swing.JOptionPane;


public class TestOptions {
	
	public static void main(String[] args) {
		/*
		//message dialogs
		 * 
		JOptionPane.showMessageDialog(null, "Hello");
		JOptionPane.showMessageDialog(null, "Content","Title",
				JOptionPane.INFORMATION_MESSAGE);
		
		
		JOptionPane.showMessageDialog(null, "Are you sure","Exit",
				JOptionPane.QUESTION_MESSAGE);
		
		JOptionPane.showMessageDialog(null, "Number Format","Error",
				JOptionPane.ERROR_MESSAGE);
		
		JOptionPane.showMessageDialog(null, "Content","Title",
				JOptionPane.DEFAULT_OPTION);
				
		
		// input dialogs
		
		String name= JOptionPane.showInputDialog("What is your name");
		
		//System.out.println("My name is: "+name);
		JOptionPane.showMessageDialog(null, name);
		
		String strAge= JOptionPane.showInputDialog("How old are you");
		int age= Integer.parseInt(strAge);
		
		JOptionPane.showMessageDialog(null, "I am "+age,
				"My name is "+name
				+" My age is"+age, JOptionPane.INFORMATION_MESSAGE);
		
	
		
		String []days= {"MOnday","Tuesday","Wednesday", "Sunday"};
		String day= (String)JOptionPane.showInputDialog(null,"What day is today",
				"Select",JOptionPane.QUESTION_MESSAGE,
				null,days,days[2]);
		
		System.out.println("Today is: "+day);
		JOptionPane.showMessageDialog(null, "Today is "+day);


	// confirmation dialogs
		
		int data=JOptionPane.showConfirmDialog(null, "Do you want to exit",
				"Exit",JOptionPane.YES_NO_CANCEL_OPTION);
		
		if(data==JOptionPane.YES_OPTION) {
			System.out.println("the YES button is selected");
		}
		else if(data==JOptionPane.NO_OPTION) {
			System.out.println("the NO button is selected");
		}
		else if(data==JOptionPane.CANCEL_OPTION) {
			System.out.println("the Cancel button is selected");
		}
		
		
*/
		
		Object [] options= {"Evet", "Hayir", "İptal", "Tamam"};
		int option=JOptionPane.showOptionDialog(null,"Make your decison", 
				"your decision",
				JOptionPane.YES_NO_CANCEL_OPTION,
				JOptionPane.QUESTION_MESSAGE,
				null,options,options[1]);
		
		System.out.println(option);
		
		
	}
}
























