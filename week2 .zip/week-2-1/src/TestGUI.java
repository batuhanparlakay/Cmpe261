import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class TestGUI extends JFrame implements ActionListener
,MouseListener,KeyListener{
	// define global variables
	private JLabel lblFirst,lblSecond,lblResult,lblInfo;
	private JTextField txtOne,txtTwo,txtResult;
	private JButton btnCalculate,btnReset,btnExit;
	private Calculate calculate;
	private JRadioButton rdAdd, rdSub,rdMul,rdDiv;
	private ButtonGroup btnGroups;
	private JCheckBox chInfo;

	
	public TestGUI() {
		
		//set Layout
		setLayout(null);
		init();
		calculate= new Calculate();
		
		// register txtONe to respond mouse events
		txtOne.addMouseListener(this);
		btnCalculate.addMouseListener(this);
		btnReset.addMouseListener(this);
		txtTwo.addKeyListener(this);
			
		
		
		// set my GUI parameters
		setSize(600, 600);
		setTitle("Calculate");
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		getContentPane().setBackground(Color.pink);
		setResizable(false);
	}
	
	// design GUI
	private void init() {
		
		//initialize global variables
				lblFirst= new JLabel("Frist");
				lblFirst.setForeground(Color.red);
				lblFirst.setLocation(10, 10);
				lblFirst.setSize(100,50);
				add(lblFirst);
				
				// set txtOne
				txtOne= new JTextField();
				txtOne.setLocation(115, 10);
				txtOne.setSize(100, 50);
				add(txtOne);
				txtOne.setToolTipText("Enter Integer Number");
				
				lblSecond= new JLabel("Second");
				lblSecond.setForeground(Color.red);
				lblSecond.setLocation(10, 60);
				lblSecond.setSize(100,50);
				add(lblSecond);
				
				// set txtTwo
				txtTwo= new JTextField();
				txtTwo.setLocation(115, 60);
				txtTwo.setSize(100, 50);
				add(txtTwo);
				
				
				lblResult= new JLabel("Result");
				lblResult.setForeground(Color.red);
				lblResult.setLocation(10, 110);
				lblResult.setSize(100,50);
				add(lblResult);
				
				// set txtResult
				txtResult= new JTextField();
				txtResult.setLocation(115, 110);
				txtResult.setSize(100, 50);
				add(txtResult);
				txtResult.setEditable(false);
				
				
				// set Buttons
						btnCalculate= new JButton("Calculate");
						btnCalculate.setLocation(10, 200);
						btnCalculate.setSize(100, 50);
						add(btnCalculate);
						
						btnReset= new JButton("Reset");
						btnReset.setLocation(120, 200);
						btnReset.setSize(100, 50);
						add(btnReset);
						
						
						btnExit= new JButton("Exit");
						btnExit.setLocation(240, 200);
						btnExit.setSize(100, 50);
						add(btnExit);
						
						// register buttons to respond actions
						
						//btnCalculate.addActionListener(this);
						//btnReset.addActionListener(this);
						btnExit.addActionListener(this);
						
						// set radio buttons
						
						btnGroups= new ButtonGroup();
						rdAdd= new JRadioButton("Add");
						rdAdd.setLocation(10, 300);
						rdAdd.setSize(80, 50);
						add(rdAdd);
						
						
						
						rdSub= new JRadioButton("Sub");
						rdSub.setLocation(100, 300);
						rdSub.setSize(80, 50);
						add(rdSub);
						
						
						
						
						rdMul= new JRadioButton("Mul");
						rdMul.setLocation(190, 300);
						rdMul.setSize(80, 50);
						add(rdMul);
						
						
						
					
						rdDiv= new JRadioButton("Div");
						rdDiv.setLocation(280, 300);
						rdDiv.setSize(80, 50);
						add(rdDiv);
						
						//make a group for radio buttons
						btnGroups.add(rdSub);
						btnGroups.add(rdAdd);
						btnGroups.add(rdMul);
						btnGroups.add(rdDiv);
						rdAdd.setSelected(true);
						
						chInfo= new JCheckBox("Show Result in Label");
						chInfo.setLocation(10,370 );
						chInfo.setSize(200, 50);
						add(chInfo);
						chInfo.setSelected(true);
						
						lblInfo= new JLabel();
						lblInfo.setForeground(Color.BLACK);
						lblInfo.setLocation(10,500 );
						lblInfo.setSize(200, 50);
						add(lblInfo);
						

			
		
	}
	
	public static void main(String[] args) {
		new TestGUI();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
	
		if(e.getSource().equals(btnCalculate))
			calculate();
		else if(e.getSource().equals(btnReset))
			reset();
		else if(e.getSource().equals(btnExit))
			exit();
		
	}
	
	// calculate data
	private void calculate() {
		int total=0;

		try {
		int first=Integer.parseInt(txtOne.getText().trim());
		int second=Integer.parseInt(txtTwo.getText().trim());
		
		if(rdAdd.isSelected())
			total=calculate.add(first, second);
		else if(rdSub.isSelected())
			total=calculate.sub(first, second);
		else if(rdMul.isSelected())
			total=calculate.mul(first, second);
						
		else if(rdDiv.isSelected())
			total=calculate.div(first, second);
			
			
		txtResult.setText(String.valueOf(total));
		
		if(chInfo.isSelected()) {
			lblInfo.setText("Result is: "+total);
		}
		else {
			lblInfo.setText("");
		}
		}
		catch(NumberFormatException ee) {
			JOptionPane.showMessageDialog(
					this,"Input Ineger number","Unvalid NUmber",
					JOptionPane.ERROR_MESSAGE
					);
		}
		
		
	}

	// reset
		private void reset() {
			txtOne.setText("");
			txtTwo.setText("");
			txtResult.setText("");
			rdAdd.setSelected(true);
			chInfo.setSelected(true);
			lblInfo.setText("");
			
		}
		
		//exit
		private void exit() {
			System.exit(1);
		}

		@Override
		public void mouseClicked(MouseEvent e) {
		
			if(e.getSource().equals(btnCalculate))
			calculate();
			else if(e.getSource().equals(btnReset))
				reset();
			
		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseEntered(MouseEvent e) {
		
			//JOptionPane.showMessageDialog(this, "mouse entered");
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void keyTyped(KeyEvent e) {
			
		}

		@Override
		public void keyPressed(KeyEvent e) {
			if(e.getKeyCode()==e.VK_ENTER)
				calculate();
			else if(e.getKeyCode()==e.VK_ESCAPE)
				exit();

			
		}

		@Override
		public void keyReleased(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}
}





