import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class RmiServer {
	public static void main(String[] args) {
		try {
			RmiInstance isntance= new RmiInstance();
			rmiMyInteface  share= (rmiMyInteface)UnicastRemoteObject.
					exportObject(isntance, 0);
			Registry reg= LocateRegistry.getRegistry();
			reg.bind("bilgi",share);
			System.out.println("Rmi server is ready...");
			
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println("errir in RMI server");
		}
	}

}
