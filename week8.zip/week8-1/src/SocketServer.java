import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class SocketServer {
	public static void main(String[] args) {
		ServerSocket myServer;
		Socket mySocket;
		try {
			myServer= new ServerSocket(7000);
			System.out.println("Waiting for a client");
			mySocket=myServer.accept();
			System.out.println("I have a clinet...");
			OutputStream out= mySocket.getOutputStream();
			DataOutputStream dataout= new DataOutputStream(out);
			dataout.writeUTF("Helle client...");
			
			InputStream in= mySocket.getInputStream();
			DataInputStream datain= new DataInputStream(in);
			System.out.println(datain.readUTF());
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error in server");
		}
	}

}
