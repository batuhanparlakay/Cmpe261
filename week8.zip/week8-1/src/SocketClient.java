import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

public class SocketClient {
	public static void main(String[] args) {
		try {
			Socket client= new Socket("127.0.0.1", 7000);
			InputStream in= client.getInputStream();
			DataInputStream datain= new DataInputStream(in);
			String msg= datain.readUTF();
			System.out.println("the message is: "+msg);
			OutputStream out=client.getOutputStream();
			DataOutputStream dataout=new DataOutputStream(out);
			dataout.writeUTF("Thanks...");
			
		
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println("error in client");
		}
	}

}
