import java.rmi.RemoteException;

public class RmiInstance implements rmiMyInteface{

	@Override
	public int add(int a, int b) throws RemoteException {
		// TODO Auto-generated method stub
		return a+b;
	}
	
	public void hi() {
		System.out.println("Hi");
	}

	@Override
	public int sub(int a, int b) throws RemoteException {
		// TODO Auto-generated method stub
		return a-b;
	}

}
