import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class RmiClient {
	public static void main(String[] args) {
		try {
			Registry reg= LocateRegistry.getRegistry("localhost");
			rmiMyInteface remote= (rmiMyInteface)reg.lookup("bilgi");
			
			int sum= remote.add(300, 500);
			System.out.println("result is: "+sum);
			
			int sub= remote.sub(300, 400);
			System.out.println("result is: "+sub);
			
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println("error in rmi Client...");
		}
	}

}
